@extends('layouts.app')

@section('title', 'Data Tagihan Sales | Toko Bangunan 39')

@section('content')
<!-- Wrapper Halaman Internal (Persis 100% seperti Piutang Pelanggan / Penjualan) -->
<div class="p-lg space-y-lg flex-1">

    <!-- Header Halaman -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-md border-b border-outline-variant/60 pb-md">
        <div>
            <h2 class="font-headline-xl text-headline-xl text-on-surface uppercase text-primary font-bold tracking-tight">Data Tagihan Sales</h2>
            <p class="text-xs text-on-surface-variant mt-0.5">Kelola penugasan penagihan sales, cetak surat jalan tagihan harian, dan proses setoran pelunasan invoice.</p>
        </div>
        
        <div class="flex justify-end gap-2">
            <a class="flex items-center gap-1.5 bg-primary text-on-primary px-4 py-2 rounded-lg text-xs font-bold hover:brightness-110 shadow-sm transition-all" href="{{ route('data-tagihan.create') }}">
                <span class="material-symbols-outlined text-md">add</span>
                <span>Buat Tagihan Baru</span>
            </a>
        </div>
    </div>

    <!-- Grid Kartu Summary (Persis seperti Piutang Pelanggan) -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-md">
        <div class="bg-surface-container-lowest border border-outline-variant p-md rounded-xl shadow-sm space-y-1">
            <p class="text-on-surface-variant font-bold text-[11px] uppercase tracking-wider">Total Lembaran Tagihan</p>
            <h3 class="text-xl font-black text-primary">{{ number_format($totalSheets, 0, ',', '.') }} Dokumen</h3>
            <div class="flex items-center gap-1 text-primary pt-1 text-xs font-medium">
                <span class="material-symbols-outlined text-sm">description</span>
                <span>Dokumen penagihan</span>
            </div>
        </div>

        <div class="bg-surface-container-lowest border border-outline-variant p-md rounded-xl shadow-sm space-y-1">
            <p class="text-on-surface-variant font-bold text-[11px] uppercase tracking-wider">Nominal Tagihan Dibawa</p>
            <h3 class="text-xl font-black text-amber-600">Rp {{ number_format($totalNominalDibawa, 0, ',', '.') }}</h3>
            <div class="flex items-center gap-1 text-amber-600 pt-1 text-xs font-medium">
                <span class="material-symbols-outlined text-sm">local_shipping</span>
                <span>Sedang dibawa sales</span>
            </div>
        </div>

        <div class="bg-surface-container-lowest border border-outline-variant p-md rounded-xl shadow-sm space-y-1">
            <p class="text-on-surface-variant font-bold text-[11px] uppercase tracking-wider">Total Setoran Terkumpul</p>
            <h3 class="text-xl font-black text-emerald-600">Rp {{ number_format($totalNominalSelesai, 0, ',', '.') }}</h3>
            <div class="flex items-center gap-1 text-emerald-600 pt-1 text-xs font-medium">
                <span class="material-symbols-outlined text-sm">trending_up</span>
                <span>Sudah disetorkan</span>
            </div>
        </div>
    </div>

    <!-- Notifications -->
    @if(session('success'))
        <div class="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
            <span class="material-symbols-outlined text-sm text-emerald-600">check_circle</span>
            <span>{{ session('success') }}</span>
        </div>
    @endif
    @if(session('info'))
        <div class="p-4 rounded-xl bg-blue-50 border border-blue-200 text-blue-800 text-xs font-semibold flex items-center gap-2">
            <span class="material-symbols-outlined text-sm text-blue-600">info</span>
            <span>{{ session('info') }}</span>
        </div>
    @endif
    @if($errors->any())
        <div class="p-4 rounded-xl bg-error/10 border border-error/30 text-error text-xs font-semibold flex items-center gap-2">
            <span class="material-symbols-outlined text-sm text-error">error</span>
            <span>{{ $errors->first() }}</span>
        </div>
    @endif

    <!-- Panel Tabel Ledger (Persis seperti Receivables Oversight Ledger) -->
    <div class="bg-surface-container-lowest border border-outline-variant rounded-xl overflow-hidden shadow-sm">
        <div class="px-4 py-3 border-b border-outline-variant flex flex-col sm:flex-row justify-between sm:items-center gap-2 bg-surface-container-low/40">
            <div>
                <h4 class="text-sm font-black text-on-surface tracking-tight">Dokumen Tagihan Sales</h4>
                @if (($search ?? '') !== '')
                    <p class="mt-0.5 text-[11px] text-on-surface-variant">Hasil pencarian: <strong>{{ $search }}</strong></p>
                @endif
            </div>

            <form method="GET" action="{{ route('data-tagihan.index') }}" class="flex w-full flex-wrap items-center gap-2 sm:w-auto">
                <select name="sales_id" onchange="this.form.submit()" class="h-10 rounded-xl border border-outline-variant bg-white px-3 text-xs font-bold text-on-surface outline-none focus:border-primary focus:ring-2 focus:ring-primary/10">
                    <option value="">-- Semua Salesman --</option>
                    @foreach($salesmen as $s)
                        <option value="{{ $s->id }}" {{ $salesFilter == $s->id ? 'selected' : '' }}>{{ $s->nama_sales }} ({{ $s->kode_sales }})</option>
                    @endforeach
                </select>

                <select name="status" onchange="this.form.submit()" class="h-10 rounded-xl border border-outline-variant bg-white px-3 text-xs font-bold text-on-surface outline-none focus:border-primary focus:ring-2 focus:ring-primary/10">
                    <option value="">-- Semua Status --</option>
                    <option value="DIBAWA" {{ $statusFilter === 'DIBAWA' ? 'selected' : '' }}>DIBAWA (Proses Penagihan)</option>
                    <option value="SELESAI" {{ $statusFilter === 'SELESAI' ? 'selected' : '' }}>SELESAI (Sudah Disetorkan)</option>
                </select>

                <div class="relative min-w-0 flex-1 sm:w-64">
                    <span class="material-symbols-outlined pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-lg text-on-surface-variant">search</span>
                    <input type="text" name="search" value="{{ $search ?? '' }}" placeholder="Cari No. DO, toko, invoice..." class="h-10 w-full rounded-full border border-outline-variant bg-white pl-9 pr-4 text-xs outline-none focus:border-primary focus:ring-2 focus:ring-primary/10" autocomplete="off">
                </div>

                <button type="submit" class="flex h-10 items-center gap-1 rounded-xl bg-primary px-3 text-xs font-bold text-on-primary hover:brightness-110">
                    <span class="material-symbols-outlined text-base">search</span>Cari
                </button>

                @if(($search ?? '') !== '' || ($salesFilter ?? '') !== '' || ($statusFilter ?? '') !== '')
                    <a href="{{ route('data-tagihan.index') }}" class="flex h-10 items-center gap-1 rounded-xl border border-outline-variant bg-white px-3 text-xs font-bold text-on-surface-variant hover:bg-surface-container-low">
                        <span class="material-symbols-outlined text-base">close</span>Reset
                    </a>
                @endif
            </form>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="bg-surface-container-low border-b border-outline-variant text-on-surface-variant font-bold">
                        <th class="px-4 py-3">No. DO Tagihan</th>
                        <th class="px-4 py-3">Tanggal</th>
                        <th class="px-4 py-3">Salesman</th>
                        <th class="px-4 py-3 text-center">Jumlah Nota</th>
                        <th class="px-4 py-3 text-right">Total Tagihan</th>
                        <th class="px-4 py-3 text-right">Total Setoran</th>
                        <th class="px-4 py-3 text-center">Status</th>
                        <th class="px-4 py-3 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-outline-variant/60">
                    @forelse($tagihans as $item)
                        <tr class="hover:bg-surface-container-low/30 transition-colors">
                            <td class="px-4 py-3.5 font-bold text-primary font-mono tracking-wide">
                                {{ $item->no_do }}
                            </td>
                            <td class="px-4 py-3.5 text-on-surface-variant">
                                {{ optional($item->tgl_dt)->translatedFormat('d M Y') }}
                            </td>
                            <td class="px-4 py-3.5 font-semibold text-on-surface">
                                {{ $item->salesman_name }}
                            </td>
                            <td class="px-4 py-3.5 text-center">
                                <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-surface-container-high text-on-surface-variant uppercase tracking-wider">
                                    {{ $item->details->count() }} Toko
                                </span>
                            </td>
                            <td class="px-4 py-3.5 text-right font-bold text-on-surface">
                                Rp {{ number_format($item->total_tagihan, 0, ',', '.') }}
                            </td>
                            <td class="px-4 py-3.5 text-right font-bold text-emerald-600">
                                @if($item->status === 'SELESAI')
                                    Rp {{ number_format($item->total_bayar, 0, ',', '.') }}
                                @else
                                    <span class="text-on-surface-variant/60 font-normal">-</span>
                                @endif
                            </td>
                            <td class="px-4 py-3.5 text-center">
                                @if($item->status === 'SELESAI')
                                    <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800 uppercase tracking-wider">
                                        SELESAI
                                    </span>
                                @else
                                    <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-800 uppercase tracking-wider">
                                        DIBAWA SALES
                                    </span>
                                @endif
                            </td>
                            <td class="px-4 py-3.5 text-center">
                                <div class="flex items-center justify-center gap-1.5">
                                    <a href="{{ route('data-tagihan.show', $item->id) }}" class="flex items-center gap-1 border border-outline-variant bg-white px-2.5 py-1.5 rounded-lg text-on-surface hover:bg-surface-container-low text-xs font-bold transition-colors">
                                        <span class="material-symbols-outlined text-sm">visibility</span>
                                        <span>Detail</span>
                                    </a>
                                    <a href="{{ route('data-tagihan.print', $item->id) }}" target="_blank" class="flex items-center gap-1 bg-primary text-on-primary px-2.5 py-1.5 rounded-lg text-xs font-bold hover:brightness-110 shadow-sm transition-all">
                                        <span class="material-symbols-outlined text-sm">print</span>
                                        <span>Print</span>
                                    </a>
                                    @if($item->status === 'DIBAWA')
                                        <a href="{{ route('data-tagihan.settle', $item->id) }}" class="flex items-center gap-1 bg-emerald-600 text-white px-2.5 py-1.5 rounded-lg text-xs font-bold hover:bg-emerald-700 shadow-sm transition-all">
                                            <span class="material-symbols-outlined text-sm">payments</span>
                                            <span>Setoran</span>
                                        </a>
                                        <form action="{{ route('data-tagihan.destroy', $item->id) }}" method="POST" onsubmit="return confirm('Hapus lembar tagihan ini?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="flex items-center justify-center p-1.5 rounded-lg border border-error/30 bg-error/10 text-error hover:bg-error hover:text-white transition-colors">
                                                <span class="material-symbols-outlined text-sm">delete</span>
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="px-4 py-8 text-center text-on-surface-variant font-medium">
                                Belum ada dokumen Data Tagihan Sales.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($tagihans->hasPages())
            <div class="px-4 py-3 border-t border-outline-variant bg-surface-container-low/20">
                {{ $tagihans->links() }}
            </div>
        @endif
    </div>
</div>
@endsection
