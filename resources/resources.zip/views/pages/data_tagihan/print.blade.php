<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DATA TAGIHAN — {{ $tagihan->no_do }}</title>
    <style>
        @page {
            size: A4 portrait;
            margin: 15mm;
        }

        body {
            font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
            font-size: 13px;
            color: #000;
            background: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
        }

        h1.title {
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            letter-spacing: 1px;
            margin-bottom: 25px;
            text-transform: uppercase;
        }

        .header-info {
            margin-bottom: 20px;
            font-size: 13px;
            line-height: 1.6;
        }

        .header-info table {
            border-collapse: collapse;
        }

        .header-info td {
            padding: 2px 8px 2px 0;
            vertical-align: top;
        }

        .header-info td.label {
            font-weight: bold;
            width: 90px;
        }

        .header-info td.colon {
            width: 15px;
        }

        table.data-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table.data-table th, 
        table.data-table td {
            border: 1px solid #000;
            padding: 8px 10px;
            font-size: 12px;
        }

        table.data-table th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-transform: uppercase;
            text-align: center;
        }

        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-left { text-align: left; }

        .total-row {
            font-weight: bold;
            background-color: #fdfdfd;
        }

        .footer-signatures {
            margin-top: 50px;
            width: 100%;
            display: flex;
            justify-content: space-between;
        }

        .sig-box {
            text-align: center;
            width: 25%;
        }

        .sig-box .title-sig {
            font-weight: bold;
            margin-bottom: 70px;
        }

        .sig-box .line-sig {
            border-bottom: 1px solid #000;
            display: inline-block;
            width: 80%;
        }

        @media print {
            body {
                padding: 0;
            }
            .no-print {
                display: none !important;
            }
            table.data-table th {
                background-color: #f2f2f2 !important;
                -webkit-print-color-adjust: exact;
            }
        }

        .btn-print-action {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #0071E3;
            color: white;
            border: none;
            padding: 10px 18px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
        }
        .btn-print-action:hover {
            background: #0077ED;
        }
    </style>
</head>
<body>

    <button onclick="window.print()" class="btn-print-action no-print">🖨️ Cetak Dokumen</button>

    <div class="container">
        <!-- Title -->
        <h1 class="title">DATA TAGIHAN</h1>

        <!-- Header Info -->
        <div class="header-info">
            <table>
                <tr>
                    <td class="label">no do</td>
                    <td class="colon">:</td>
                    <td style="font-weight: bold;">{{ $tagihan->no_do }}</td>
                </tr>
                <tr>
                    <td class="label">tgl dt</td>
                    <td class="colon">:</td>
                    <td>{{ optional($tagihan->tgl_dt)->format('d-M-Y') }}</td>
                </tr>
                <tr>
                    <td class="label">salesman</td>
                    <td class="colon">:</td>
                    <td style="font-weight: bold;">{{ $tagihan->salesman_name }}</td>
                </tr>
            </table>
        </div>

        <!-- Table Data -->
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 5%;">no</th>
                    <th style="width: 20%;">no inv</th>
                    <th style="width: 12%;">tgl inv</th>
                    <th style="width: 13%;">tgl jatuh tempo</th>
                    <th style="width: 22%;">nama toko</th>
                    <th style="width: 16%;">nominal tagihan</th>
                    <th style="width: 12%;">BAYAR</th>
                    <th style="width: 12%;">TF/CASH</th>
                </tr>
            </thead>
            <tbody>
                @foreach($tagihan->details as $index => $detail)
                    <tr>
                        <td class="text-center">{{ $index + 1 }}</td>
                        <td class="text-center">{{ $detail->no_invoice }}</td>
                        <td class="text-center">{{ optional($detail->tgl_inv)->format('d-M-Y') ?? '-' }}</td>
                        <td class="text-center">{{ optional($detail->tgl_jatuh_tempo)->format('d-M-Y') ?? '-' }}</td>
                        <td class="text-left" style="text-transform: uppercase;">{{ $detail->nama_toko }}</td>
                        <td class="text-right">{{ number_format($detail->nominal_tagihan, 0, ',', '.') }}</td>
                        <td class="text-right">
                            @if($tagihan->status === 'SELESAI' && $detail->bayar > 0)
                                {{ number_format($detail->bayar, 0, ',', '.') }}
                            @endif
                        </td>
                        <td class="text-center">
                            @if($tagihan->status === 'SELESAI' && $detail->metode_bayar)
                                {{ $detail->metode_bayar }}
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
            <tfoot>
                <tr class="total-row">
                    <td colspan="5" class="text-center" style="padding: 10px; text-transform: uppercase;">TOTAL TAGIHAN YANG DI BAWA</td>
                    <td class="text-right" style="padding: 10px; font-size: 13px;">{{ number_format($tagihan->total_tagihan, 0, ',', '.') }}</td>
                    <td></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>

        <!-- Footer Signatures -->
        <div class="footer-signatures">
            <div class="sig-box">
                <div class="title-sig">Dibuat Oleh</div>
                <div>( &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; )</div>
            </div>
            <div class="sig-box">
                <div class="title-sig">Dibawa Oleh</div>
                <div>( &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; )</div>
            </div>
            <div class="sig-box">
                <div class="title-sig">Diketahui Oleh</div>
                <div>( &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; )</div>
            </div>
        </div>
    </div>

</body>
</html>
